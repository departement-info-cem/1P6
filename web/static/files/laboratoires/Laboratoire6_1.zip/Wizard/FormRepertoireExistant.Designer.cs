﻿namespace Wizard
{
    partial class FormRepertoireExistant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInstruction = new System.Windows.Forms.Label();
            this.txtCheminAcces = new System.Windows.Forms.TextBox();
            this.btnVerifier = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.lblReponse = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblInstruction
            // 
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstruction.Location = new System.Drawing.Point(20, 24);
            this.lblInstruction.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(312, 20);
            this.lblInstruction.TabIndex = 2;
            this.lblInstruction.Text = "Est-ce que le répertoire ou le fichier existe?";
            // 
            // txtCheminAcces
            // 
            this.txtCheminAcces.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCheminAcces.Location = new System.Drawing.Point(24, 63);
            this.txtCheminAcces.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCheminAcces.Name = "txtCheminAcces";
            this.txtCheminAcces.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtCheminAcces.Size = new System.Drawing.Size(754, 26);
            this.txtCheminAcces.TabIndex = 3;
            // 
            // btnVerifier
            // 
            this.btnVerifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerifier.Location = new System.Drawing.Point(24, 114);
            this.btnVerifier.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnVerifier.Name = "btnVerifier";
            this.btnVerifier.Size = new System.Drawing.Size(352, 39);
            this.btnVerifier.TabIndex = 4;
            this.btnVerifier.Text = "Vérifier";
            this.btnVerifier.UseVisualStyleBackColor = true;
            // 
            // btnQuitter
            // 
            this.btnQuitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitter.Location = new System.Drawing.Point(417, 118);
            this.btnQuitter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(361, 35);
            this.btnQuitter.TabIndex = 5;
            this.btnQuitter.Text = "Quitter";
            this.btnQuitter.UseVisualStyleBackColor = true;
            // 
            // lblReponse
            // 
            this.lblReponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReponse.Location = new System.Drawing.Point(371, 23);
            this.lblReponse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReponse.Name = "lblReponse";
            this.lblReponse.Size = new System.Drawing.Size(150, 21);
            this.lblReponse.TabIndex = 6;
            // 
            // FormRepertoireExistant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 171);
            this.Controls.Add(this.lblReponse);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnVerifier);
            this.Controls.Add(this.txtCheminAcces);
            this.Controls.Add(this.lblInstruction);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormRepertoireExistant";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Répertoire existant";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInstruction;
        private System.Windows.Forms.TextBox txtCheminAcces;
        private System.Windows.Forms.Button btnVerifier;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Label lblReponse;
    }
}