﻿namespace Wizard
{
    partial class FormContratLicence
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormContratLicence));
            this.lblContrat = new System.Windows.Forms.Label();
            this.lblInstruction = new System.Windows.Forms.Label();
            this.txtReponse = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblContrat
            // 
            this.lblContrat.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContrat.Location = new System.Drawing.Point(12, 9);
            this.lblContrat.Name = "lblContrat";
            this.lblContrat.Size = new System.Drawing.Size(844, 755);
            this.lblContrat.TabIndex = 0;
            this.lblContrat.Text = resources.GetString("lblContrat.Text");
            // 
            // lblInstruction
            // 
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstruction.Location = new System.Drawing.Point(10, 762);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(627, 37);
            this.lblInstruction.TabIndex = 7;
            this.lblInstruction.Text = "Écrivez \"oui\" si vous acceptez les clauses du contrat:";
            // 
            // txtReponse
            // 
            this.txtReponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReponse.Location = new System.Drawing.Point(643, 767);
            this.txtReponse.Name = "txtReponse";
            this.txtReponse.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtReponse.Size = new System.Drawing.Size(193, 32);
            this.txtReponse.TabIndex = 8;
            // 
            // FormContratLicence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 818);
            this.Controls.Add(this.txtReponse);
            this.Controls.Add(this.lblInstruction);
            this.Controls.Add(this.lblContrat);
            this.Name = "FormContratLicence";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contrat de licence";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblContrat;
        private System.Windows.Forms.Label lblInstruction;
        private System.Windows.Forms.TextBox txtReponse;
    }
}