﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wizard
{
    public partial class FormMotDePasse : Form
    {
        const string UTILISATEUR = "Étudiant_2P6";
        const string MOT_DE_PASSE = "mON MOT de paSse NE deVraIt pAS Être En clAIR DAns l'aPPlIcATion...";

        public FormMotDePasse()
        {
            InitializeComponent();
        }
    }
}
