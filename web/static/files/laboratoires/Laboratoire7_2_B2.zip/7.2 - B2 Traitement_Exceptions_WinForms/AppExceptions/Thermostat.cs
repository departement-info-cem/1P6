using System;

namespace AppExceptions
{
    /// ------------------------------------------------------------------------------------
    /// <summary>
    /// Mod�lise un thermostat �lectronique contr�lant la temp�rature d'une 
    /// plinthe de chauffage.
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public class Thermostat
    {
        #region Constantes
        /// ================================================================================
        /// <summary>
        /// Temp�rature minimale autoris�e par un Thermostat
        /// </summary>
        public const double MIN_TEMPERATURE = 5.0;

        /// ================================================================================
        /// <summary>
        /// Temp�rature maximale autoris�e par un Thermostat
        /// </summary>
        public const double MAX_TEMPERATURE = 35.0;

        /// ================================================================================
        /// <summary>
        /// Temp�rature initiale d'un Thermostat
        /// </summary>
        private const double TEMPERATURE_D�FAUT = 20.0;

        #endregion

        #region CHAMPS (variable membre) ET PROPRI�T�
        ///==================================================================================
        private double m_temperature;
        /// ---------------------------------------------------------------------------------
        /// <summary>
        ///    Obtient la temp�rature actuelle du thermostat
        /// </summary>
        public double Temperature
        {
            get { return m_temperature; }
            protected set
            {
                if (value < MIN_TEMPERATURE || value > MAX_TEMPERATURE)
                    throw new ArgumentOutOfRangeException();
                m_temperature = value;
            }
    }
        #endregion

        #region CONSTRUCTEUR
        ///======================================================================================
        /// <summary>
        ///   Initialise une nouvelle instance de la classe Thermostat. 
        /// </summary>
        ///--------------------------------------------------------------------------------------
        public Thermostat(double pTemperature = TEMPERATURE_D�FAUT)
        {
            Temperature = pTemperature;
        }

        #endregion

        #region M�THODES
        ///==================================================================================
        /// <summary>
        ///   Augmente la temp�rature d'un degr�.
        /// </summary>
        /// ---------------------------------------------------------------------------------
        public void AugmenterTemperature()
        {
            Temperature++;
        }
        ///==================================================================================
        /// <summary>
        ///   Diminue la temp�rature d'un degr�.
        /// </summary>
        /// ---------------------------------------------------------------------------------
        public void DiminuerTemperature()
        {
            Temperature--;
        }

        #endregion
    }
}
