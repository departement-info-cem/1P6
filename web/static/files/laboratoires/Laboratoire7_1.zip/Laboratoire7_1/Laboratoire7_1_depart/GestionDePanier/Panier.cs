﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionDePanier
{
    public class Panier
    {
        public List<Produit> Produits { get; private set; }

        public double PrixTotal
        {
            get
            {
                double prixTotal = 0;
                foreach (Produit p in Produits)
                {
                    prixTotal += p.Prix;
                }
                return prixTotal;
            }
        }

        public Panier()
        {
            Produits = new List<Produit>();
        }
        public void AjouterProduit(Produit p)
        {
            if(p != null) Produits.Add(p);
        }
        public void RetirerProduit(Produit p)
        {
            if (p != null) Produits.Remove(p);
        }
    }
}
