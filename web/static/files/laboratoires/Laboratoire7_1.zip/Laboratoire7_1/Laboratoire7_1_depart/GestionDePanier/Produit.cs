﻿using System;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GestionDePanier
{
    public class Produit
    {
        #region Propriétés
        public string Nom { get; private set; }
        public double Prix { get; private set; }
        

        #endregion

        #region Constructeur

        public Produit(string nom, double prix)
        {
            Nom = nom;
            Prix = prix;         
            
        }

        #endregion

        #region Méthodes publiques

        public override string ToString()
        {
            return $"{Nom} : {Prix}";
        }

        #endregion
    }
}