namespace GestionDePanier
{
    public partial class FrmPanier : Form
    {
        public List<Produit> TousLesProduits { get; private set; }
        public Panier PanierCourant { get; private set; }
        public FrmPanier()
        {
            InitializeComponent();
            PanierCourant = new Panier();
            TousLesProduits = new List<Produit>();
            
        }

        
    }
}
