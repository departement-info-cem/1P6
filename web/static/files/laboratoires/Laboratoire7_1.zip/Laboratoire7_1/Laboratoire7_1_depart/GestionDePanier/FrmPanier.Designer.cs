﻿namespace GestionDePanier
{
    partial class FrmPanier
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel5 = new Panel();
            txtTotal = new TextBox();
            label1 = new Label();
            label2 = new Label();
            lstProduitsDansLePanier = new ListBox();
            panel6 = new Panel();
            label3 = new Label();
            lstTousLesProduits = new ListBox();
            panel7 = new Panel();
            txtPrix = new TextBox();
            btnAnnuler = new Button();
            btnEnregistrerProduit = new Button();
            lblPrix = new Label();
            txtNom = new TextBox();
            lblNom = new Label();
            btnRetirerDuPanier = new Button();
            btnAjouterAuPanier = new Button();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            SuspendLayout();
            // 
            // panel5
            // 
            panel5.BackColor = Color.Turquoise;
            panel5.Controls.Add(txtTotal);
            panel5.Controls.Add(label1);
            panel5.Controls.Add(label2);
            panel5.Controls.Add(lstProduitsDansLePanier);
            panel5.Location = new Point(456, 152);
            panel5.Name = "panel5";
            panel5.Size = new Size(345, 254);
            panel5.TabIndex = 41;
            // 
            // txtTotal
            // 
            txtTotal.Location = new Point(204, 218);
            txtTotal.Name = "txtTotal";
            txtTotal.ReadOnly = true;
            txtTotal.Size = new Size(123, 23);
            txtTotal.TabIndex = 39;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(149, 220);
            label1.Name = "label1";
            label1.Size = new Size(36, 15);
            label1.TabIndex = 36;
            label1.Text = "Total:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 16);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 35;
            label2.Text = "Panier";
            // 
            // lstProduitsDansLePanier
            // 
            lstProduitsDansLePanier.FormattingEnabled = true;
            lstProduitsDansLePanier.ItemHeight = 15;
            lstProduitsDansLePanier.Location = new Point(18, 38);
            lstProduitsDansLePanier.Name = "lstProduitsDansLePanier";
            lstProduitsDansLePanier.Size = new Size(308, 169);
            lstProduitsDansLePanier.TabIndex = 33;
            // 
            // panel6
            // 
            panel6.BackColor = Color.LightSkyBlue;
            panel6.Controls.Add(label3);
            panel6.Controls.Add(lstTousLesProduits);
            panel6.Location = new Point(15, 152);
            panel6.Name = "panel6";
            panel6.Size = new Size(318, 254);
            panel6.TabIndex = 40;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 16);
            label3.Name = "label3";
            label3.Size = new Size(51, 15);
            label3.TabIndex = 36;
            label3.Text = "Produits";
            // 
            // lstTousLesProduits
            // 
            lstTousLesProduits.FormattingEnabled = true;
            lstTousLesProduits.ItemHeight = 15;
            lstTousLesProduits.Location = new Point(18, 38);
            lstTousLesProduits.Name = "lstTousLesProduits";
            lstTousLesProduits.Size = new Size(280, 169);
            lstTousLesProduits.TabIndex = 33;
            // 
            // panel7
            // 
            panel7.BackColor = Color.LightSkyBlue;
            panel7.Controls.Add(txtPrix);
            panel7.Controls.Add(btnAnnuler);
            panel7.Controls.Add(btnEnregistrerProduit);
            panel7.Controls.Add(lblPrix);
            panel7.Controls.Add(txtNom);
            panel7.Controls.Add(lblNom);
            panel7.Location = new Point(12, 12);
            panel7.Name = "panel7";
            panel7.Size = new Size(353, 122);
            panel7.TabIndex = 39;
            // 
            // txtPrix
            // 
            txtPrix.Location = new Point(94, 46);
            txtPrix.Name = "txtPrix";
            txtPrix.Size = new Size(240, 23);
            txtPrix.TabIndex = 38;
            // 
            // btnAnnuler
            // 
            btnAnnuler.DialogResult = DialogResult.Cancel;
            btnAnnuler.Location = new Point(261, 80);
            btnAnnuler.Name = "btnAnnuler";
            btnAnnuler.Size = new Size(75, 30);
            btnAnnuler.TabIndex = 37;
            btnAnnuler.Text = "Annuler";
            btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // btnEnregistrerProduit
            // 
            btnEnregistrerProduit.Location = new Point(136, 80);
            btnEnregistrerProduit.Name = "btnEnregistrerProduit";
            btnEnregistrerProduit.Size = new Size(119, 30);
            btnEnregistrerProduit.TabIndex = 36;
            btnEnregistrerProduit.Text = "Enregistrer";
            btnEnregistrerProduit.UseVisualStyleBackColor = true;
            // 
            // lblPrix
            // 
            lblPrix.AutoSize = true;
            lblPrix.Location = new Point(3, 50);
            lblPrix.Name = "lblPrix";
            lblPrix.Size = new Size(26, 15);
            lblPrix.TabIndex = 33;
            lblPrix.Text = "Prix";
            // 
            // txtNom
            // 
            txtNom.Location = new Point(94, 17);
            txtNom.Name = "txtNom";
            txtNom.Size = new Size(240, 23);
            txtNom.TabIndex = 32;
            // 
            // lblNom
            // 
            lblNom.AutoSize = true;
            lblNom.Location = new Point(3, 16);
            lblNom.Name = "lblNom";
            lblNom.Size = new Size(76, 15);
            lblNom.TabIndex = 31;
            lblNom.Text = "Nom produit";
            // 
            // btnRetirerDuPanier
            // 
            btnRetirerDuPanier.Location = new Point(340, 262);
            btnRetirerDuPanier.Margin = new Padding(3, 2, 3, 2);
            btnRetirerDuPanier.Name = "btnRetirerDuPanier";
            btnRetirerDuPanier.Size = new Size(110, 29);
            btnRetirerDuPanier.TabIndex = 43;
            btnRetirerDuPanier.Text = "Retirer du panier";
            btnRetirerDuPanier.UseVisualStyleBackColor = true;
            // 
            // btnAjouterAuPanier
            // 
            btnAjouterAuPanier.Location = new Point(340, 229);
            btnAjouterAuPanier.Margin = new Padding(3, 2, 3, 2);
            btnAjouterAuPanier.Name = "btnAjouterAuPanier";
            btnAjouterAuPanier.Size = new Size(110, 29);
            btnAjouterAuPanier.TabIndex = 42;
            btnAjouterAuPanier.Text = "Ajouter au panier";
            btnAjouterAuPanier.UseVisualStyleBackColor = true;
            // 
            // FrmPanier
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(814, 412);
            Controls.Add(btnRetirerDuPanier);
            Controls.Add(btnAjouterAuPanier);
            Controls.Add(panel5);
            Controls.Add(panel6);
            Controls.Add(panel7);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FrmPanier";
            Text = "Gestion de panier";
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Label lblChats;
        private ListBox lstChats;
        private ComboBox cboClients;
        private Label lblQuantite;
        private TextBox txtAge;
        private Panel panel5;
        private TextBox txtTotal;
        private Label label1;
        private Label label2;
        private ListBox lstProduitsDansLePanier;
        private Panel panel6;
        private Label label3;
        private ListBox lstTousLesProduits;
        private Panel panel7;
        private TextBox txtPrix;
        private Button btnAnnuler;
        private Button btnEnregistrerProduit;
        private Label lblPrix;
        private TextBox txtNom;
        private Label lblNom;
        private Button btnRetirerDuPanier;
        private Button btnAjouterAuPanier;
    }
}
