using FrmBanque;

namespace GestionInscription
{
    public partial class FrmInscription : Form
    {
        public List<Etudiant> Etudiants { get; private set; }
        public List<Cours> Cours { get; private set; }
        public FrmInscription()
        {
            InitializeComponent();
           

        }
       
       
    }
}
