﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrmBanque
{
    public class Etudiant
    {
        public string Nom { get; private set; }
        public string Prenom { get; private set; }   
        public List<Cours> MesCours { get; private set; }
        public Etudiant(string nom, string prenom)
        {
            Nom = nom;
            Prenom = prenom;   
            MesCours = new List<Cours>();
        }
        public Etudiant(string nom, string prenom, List<Cours> cours)
        {
            Nom = nom;
            Prenom = prenom;
            MesCours = cours;
        }
        public void InscrireDansUnCours(Cours cours)
        {
            if (cours != null && !MesCours.Contains(cours))
            {
                MesCours.Add(cours);
            }
            
        }
        public void DesinscrireDunCours(Cours cours)
        {
            MesCours.Remove(cours);           

        }
        public override string ToString()
        {
            return $"{ Nom } : {Prenom}";
        }

    }
}
