﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrmBanque
{
    public class Cours
    {
        public string Code { get; private set; }
        public string Titre { get; private set; }
        
        public Cours(string code, string titre)
        {
            Code = code;
            Titre = titre;
            
        }
        
        public  override string ToString()
        {
            return $"{Code} - {Titre}";
        }
    }
}
