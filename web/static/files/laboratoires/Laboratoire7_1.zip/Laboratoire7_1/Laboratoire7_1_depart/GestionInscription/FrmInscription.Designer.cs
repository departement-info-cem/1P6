﻿namespace GestionInscription
{
    partial class FrmInscription
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpCours = new GroupBox();
            txtTitre = new TextBox();
            btnAnnulerCours = new Button();
            btnEnregistrerCours = new Button();
            lblTitre = new Label();
            txtCode = new TextBox();
            lblCode = new Label();
            grpEtudiant = new GroupBox();
            txtPrenom = new TextBox();
            BtnAnnulerEtd = new Button();
            btnEnregistrerEtudiant = new Button();
            lblPrenom = new Label();
            txtNom = new TextBox();
            lblNom = new Label();
            grpInscription = new GroupBox();
            btnDesinscrire = new Button();
            cboCours = new ComboBox();
            cboEtudiants = new ComboBox();
            btnInscrire = new Button();
            lblCours = new Label();
            lblEtudiant = new Label();
            grpRecherche = new GroupBox();
            cboRechercheParCours = new ComboBox();
            lstEtudiants = new ListBox();
            lstCours = new ListBox();
            cboRechercheParEtudiant = new ComboBox();
            label3 = new Label();
            lnlEtudiant = new Label();
            grpCours.SuspendLayout();
            grpEtudiant.SuspendLayout();
            grpInscription.SuspendLayout();
            grpRecherche.SuspendLayout();
            SuspendLayout();
            // 
            // grpCours
            // 
            grpCours.Controls.Add(txtTitre);
            grpCours.Controls.Add(btnAnnulerCours);
            grpCours.Controls.Add(btnEnregistrerCours);
            grpCours.Controls.Add(lblTitre);
            grpCours.Controls.Add(txtCode);
            grpCours.Controls.Add(lblCode);
            grpCours.Location = new Point(375, 12);
            grpCours.Name = "grpCours";
            grpCours.Size = new Size(320, 115);
            grpCours.TabIndex = 44;
            grpCours.TabStop = false;
            grpCours.Text = "Cours";
            // 
            // txtTitre
            // 
            txtTitre.Location = new Point(68, 43);
            txtTitre.Name = "txtTitre";
            txtTitre.Size = new Size(240, 23);
            txtTitre.TabIndex = 44;
            // 
            // btnAnnulerCours
            // 
            btnAnnulerCours.DialogResult = DialogResult.Cancel;
            btnAnnulerCours.Location = new Point(234, 72);
            btnAnnulerCours.Name = "btnAnnulerCours";
            btnAnnulerCours.Size = new Size(75, 30);
            btnAnnulerCours.TabIndex = 43;
            btnAnnulerCours.Text = "Annuler";
            btnAnnulerCours.UseVisualStyleBackColor = true;
            // 
            // btnEnregistrerCours
            // 
            btnEnregistrerCours.Location = new Point(109, 72);
            btnEnregistrerCours.Name = "btnEnregistrerCours";
            btnEnregistrerCours.Size = new Size(119, 30);
            btnEnregistrerCours.TabIndex = 42;
            btnEnregistrerCours.Text = "Enregistrer";
            btnEnregistrerCours.UseVisualStyleBackColor = true;
            // 
            // lblTitre
            // 
            lblTitre.AutoSize = true;
            lblTitre.Location = new Point(9, 46);
            lblTitre.Name = "lblTitre";
            lblTitre.Size = new Size(31, 15);
            lblTitre.TabIndex = 41;
            lblTitre.Text = "Titre";
            // 
            // txtCode
            // 
            txtCode.Location = new Point(68, 17);
            txtCode.Name = "txtCode";
            txtCode.Size = new Size(240, 23);
            txtCode.TabIndex = 40;
            // 
            // lblCode
            // 
            lblCode.AutoSize = true;
            lblCode.Location = new Point(9, 20);
            lblCode.Name = "lblCode";
            lblCode.Size = new Size(35, 15);
            lblCode.TabIndex = 39;
            lblCode.Text = "Code";
            // 
            // grpEtudiant
            // 
            grpEtudiant.Controls.Add(txtPrenom);
            grpEtudiant.Controls.Add(BtnAnnulerEtd);
            grpEtudiant.Controls.Add(btnEnregistrerEtudiant);
            grpEtudiant.Controls.Add(lblPrenom);
            grpEtudiant.Controls.Add(txtNom);
            grpEtudiant.Controls.Add(lblNom);
            grpEtudiant.Location = new Point(12, 12);
            grpEtudiant.Name = "grpEtudiant";
            grpEtudiant.Size = new Size(320, 115);
            grpEtudiant.TabIndex = 43;
            grpEtudiant.TabStop = false;
            grpEtudiant.Text = "Etudiant-e";
            // 
            // txtPrenom
            // 
            txtPrenom.Location = new Point(68, 43);
            txtPrenom.Name = "txtPrenom";
            txtPrenom.Size = new Size(240, 23);
            txtPrenom.TabIndex = 44;
            // 
            // BtnAnnulerEtd
            // 
            BtnAnnulerEtd.DialogResult = DialogResult.Cancel;
            BtnAnnulerEtd.Location = new Point(234, 72);
            BtnAnnulerEtd.Name = "BtnAnnulerEtd";
            BtnAnnulerEtd.Size = new Size(75, 30);
            BtnAnnulerEtd.TabIndex = 43;
            BtnAnnulerEtd.Text = "Annuler";
            BtnAnnulerEtd.UseVisualStyleBackColor = true;
            // 
            // btnEnregistrerEtudiant
            // 
            btnEnregistrerEtudiant.Location = new Point(109, 72);
            btnEnregistrerEtudiant.Name = "btnEnregistrerEtudiant";
            btnEnregistrerEtudiant.Size = new Size(119, 30);
            btnEnregistrerEtudiant.TabIndex = 42;
            btnEnregistrerEtudiant.Text = "Enregistrer";
            btnEnregistrerEtudiant.UseVisualStyleBackColor = true;
            // 
            // lblPrenom
            // 
            lblPrenom.AutoSize = true;
            lblPrenom.Location = new Point(9, 46);
            lblPrenom.Name = "lblPrenom";
            lblPrenom.Size = new Size(49, 15);
            lblPrenom.TabIndex = 41;
            lblPrenom.Text = "Prenom";
            // 
            // txtNom
            // 
            txtNom.Location = new Point(68, 17);
            txtNom.Name = "txtNom";
            txtNom.Size = new Size(240, 23);
            txtNom.TabIndex = 40;
            // 
            // lblNom
            // 
            lblNom.AutoSize = true;
            lblNom.Location = new Point(9, 20);
            lblNom.Name = "lblNom";
            lblNom.Size = new Size(34, 15);
            lblNom.TabIndex = 39;
            lblNom.Text = "Nom";
            // 
            // grpInscription
            // 
            grpInscription.Controls.Add(btnDesinscrire);
            grpInscription.Controls.Add(cboCours);
            grpInscription.Controls.Add(cboEtudiants);
            grpInscription.Controls.Add(btnInscrire);
            grpInscription.Controls.Add(lblCours);
            grpInscription.Controls.Add(lblEtudiant);
            grpInscription.Location = new Point(47, 168);
            grpInscription.Name = "grpInscription";
            grpInscription.Size = new Size(637, 115);
            grpInscription.TabIndex = 45;
            grpInscription.TabStop = false;
            grpInscription.Text = "Inscription";
            // 
            // btnDesinscrire
            // 
            btnDesinscrire.Location = new Point(298, 67);
            btnDesinscrire.Name = "btnDesinscrire";
            btnDesinscrire.Size = new Size(119, 30);
            btnDesinscrire.TabIndex = 45;
            btnDesinscrire.Text = "Desinscrire";
            btnDesinscrire.UseVisualStyleBackColor = true;
            // 
            // cboCours
            // 
            cboCours.FormattingEnabled = true;
            cboCours.Location = new Point(298, 38);
            cboCours.Name = "cboCours";
            cboCours.Size = new Size(240, 23);
            cboCours.TabIndex = 44;
            // 
            // cboEtudiants
            // 
            cboEtudiants.FormattingEnabled = true;
            cboEtudiants.Location = new Point(9, 38);
            cboEtudiants.Name = "cboEtudiants";
            cboEtudiants.Size = new Size(240, 23);
            cboEtudiants.TabIndex = 43;
            // 
            // btnInscrire
            // 
            btnInscrire.Location = new Point(134, 67);
            btnInscrire.Name = "btnInscrire";
            btnInscrire.Size = new Size(119, 30);
            btnInscrire.TabIndex = 42;
            btnInscrire.Text = "Inscrire";
            btnInscrire.UseVisualStyleBackColor = true;
            // 
            // lblCours
            // 
            lblCours.AutoSize = true;
            lblCours.Location = new Point(298, 20);
            lblCours.Name = "lblCours";
            lblCours.Size = new Size(38, 15);
            lblCours.TabIndex = 41;
            lblCours.Text = "Cours";
            // 
            // lblEtudiant
            // 
            lblEtudiant.AutoSize = true;
            lblEtudiant.Location = new Point(9, 20);
            lblEtudiant.Name = "lblEtudiant";
            lblEtudiant.Size = new Size(34, 15);
            lblEtudiant.TabIndex = 39;
            lblEtudiant.Text = "Nom";
            // 
            // grpRecherche
            // 
            grpRecherche.Controls.Add(cboRechercheParCours);
            grpRecherche.Controls.Add(lstEtudiants);
            grpRecherche.Controls.Add(lstCours);
            grpRecherche.Controls.Add(cboRechercheParEtudiant);
            grpRecherche.Controls.Add(label3);
            grpRecherche.Controls.Add(lnlEtudiant);
            grpRecherche.Location = new Point(46, 315);
            grpRecherche.Name = "grpRecherche";
            grpRecherche.Size = new Size(637, 264);
            grpRecherche.TabIndex = 46;
            grpRecherche.TabStop = false;
            grpRecherche.Text = "Recherche";
            // 
            // cboRechercheParCours
            // 
            cboRechercheParCours.FormattingEnabled = true;
            cboRechercheParCours.Location = new Point(299, 38);
            cboRechercheParCours.Name = "cboRechercheParCours";
            cboRechercheParCours.Size = new Size(240, 23);
            cboRechercheParCours.TabIndex = 47;
            // 
            // lstEtudiants
            // 
            lstEtudiants.FormattingEnabled = true;
            lstEtudiants.ItemHeight = 15;
            lstEtudiants.Location = new Point(298, 92);
            lstEtudiants.Name = "lstEtudiants";
            lstEtudiants.Size = new Size(240, 139);
            lstEtudiants.TabIndex = 46;
            // 
            // lstCours
            // 
            lstCours.FormattingEnabled = true;
            lstCours.ItemHeight = 15;
            lstCours.Location = new Point(12, 92);
            lstCours.Name = "lstCours";
            lstCours.Size = new Size(237, 139);
            lstCours.TabIndex = 45;
            // 
            // cboRechercheParEtudiant
            // 
            cboRechercheParEtudiant.FormattingEnabled = true;
            cboRechercheParEtudiant.Location = new Point(9, 38);
            cboRechercheParEtudiant.Name = "cboRechercheParEtudiant";
            cboRechercheParEtudiant.Size = new Size(240, 23);
            cboRechercheParEtudiant.TabIndex = 43;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(298, 20);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 41;
            label3.Text = "Cours";
            // 
            // lnlEtudiant
            // 
            lnlEtudiant.AutoSize = true;
            lnlEtudiant.Location = new Point(9, 20);
            lnlEtudiant.Name = "lnlEtudiant";
            lnlEtudiant.Size = new Size(51, 15);
            lnlEtudiant.TabIndex = 39;
            lnlEtudiant.Text = "Etudiant";
            // 
            // FrmInscription
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(696, 603);
            Controls.Add(grpRecherche);
            Controls.Add(grpInscription);
            Controls.Add(grpCours);
            Controls.Add(grpEtudiant);
            Name = "FrmInscription";
            Text = "Gestion des inscriptions";
            grpCours.ResumeLayout(false);
            grpCours.PerformLayout();
            grpEtudiant.ResumeLayout(false);
            grpEtudiant.PerformLayout();
            grpInscription.ResumeLayout(false);
            grpInscription.PerformLayout();
            grpRecherche.ResumeLayout(false);
            grpRecherche.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grpCours;
        private Button btnAnnulerCours;
        private Button btnEnregistrerCours;
        private Label lblTitre;
        private TextBox txtCode;
        private Label lblCode;
        private GroupBox grpEtudiant;
        private TextBox txtPrenom;
        private Button BtnAnnulerEtd;
        private Button btnEnregistrerEtudiant;
        private Label lblPrenom;
        private TextBox txtNom;
        private Label lblNom;
        private TextBox txtTitre;
        private GroupBox grpInscription;
        private Button btnInscrire;
        private Label lblCours;
        private Label lblEtudiant;
        private Button btnDesinscrire;
        private ComboBox cboCours;
        private ComboBox cboEtudiants;
        private GroupBox grpRecherche;
       
        private ComboBox cboRecherchePar;
        private Label label3;
        private Label lnlEtudiant;
        private ComboBox cboRechercheParEtudiant;
        private ListBox lstEtudiants;
        private ListBox lstCours;
        private ComboBox cboRechercheParCours;
    }
}
